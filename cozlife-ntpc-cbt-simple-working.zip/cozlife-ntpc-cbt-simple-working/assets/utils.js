
const U=(()=>{
  const K={profile:"coz_profile_v3", attemptPrefix:"coz_attempt_v3_"};
  const toast=(m)=>alert(m);
  const isEmail=(e)=>/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e);
  const saveProfile=(p)=>localStorage.setItem(K.profile,JSON.stringify(p));
  const loadProfile=()=>{try{return JSON.parse(localStorage.getItem(K.profile)||"null")}catch{return null}};
  const parseTest=()=>{const q=new URLSearchParams(location.search);return (q.get("test")||"001").replace(/\D/g,"").slice(0,3).padStart(3,"0")};
  const saveAttempt=(a)=>localStorage.setItem(K.attemptPrefix+a.attemptId,JSON.stringify(a));
  const loadAttempt=(id)=>{try{return JSON.parse(localStorage.getItem(K.attemptPrefix+id)||"null")}catch{return null}};
  const mmss=(s)=>{s=Math.max(0,Math.floor(s));const m=String(Math.floor(s/60)).padStart(2,"0");const ss=String(s%60).padStart(2,"0");return `${m}:${ss}`;}
  return {K,toast,isEmail,saveProfile,loadProfile,parseTest,saveAttempt,loadAttempt,mmss};
})();
