
(async()=>{
  const testId=U.parseTest();
  const profile=U.loadProfile();
  if(!profile?.name||!profile?.email){U.toast("Please enter Name + Email first.");location.href="./index.html";return;}

  async function loadJSON(p){
    const r=await fetch(p,{cache:"no-store"});
    if(!r.ok) throw new Error("Fetch failed: "+p+" "+r.status);
    return await r.json();
  }
  let mock;
  try{ mock = await loadJSON(`./data/mocks/mock-${testId}.json`); }
  catch(e){ console.error(e); U.toast("Mock file missing. Re-upload ZIP correctly."); location.href="./index.html"; return; }

  const qs = mock.questions||[];
  document.getElementById("countPill").textContent = `QUESTIONS = ${qs.length}`;
  if(qs.length<2){ U.toast("Question bank not loaded correctly (only "+qs.length+"). Please redeploy the ZIP root folder."); }

  const durationSec = 5400;
  const attemptId = `${testId}_${Date.now()}_${Math.random().toString(16).slice(2)}`;
  const a = {attemptId,testId,name:profile.name,email:profile.email,start:Date.now(),timeLeft:durationSec,
    questions:qs,responses:Array(qs.length).fill(null),marked:Array(qs.length).fill(false),cur:0,submittedAt:null};
  U.saveAttempt(a);

  const el={
    qNo:document.getElementById("qNo"),
    qText:document.getElementById("qText"),
    opts:document.getElementById("opts"),
    pal:document.getElementById("pal"),
    timer:document.getElementById("timer"),
    mark:document.getElementById("mark"),
    clear:document.getElementById("clear"),
    prev:document.getElementById("prev"),
    next:document.getElementById("next"),
    submit:document.getElementById("submit")
  };

  function renderPal(){
    el.pal.innerHTML="";
    for(let i=0;i<qs.length;i++){
      const b=document.createElement("div");
      let cls="pq";
      if(a.responses[i]!=null) cls+=" a";
      if(a.marked[i]) cls+=" m";
      if(i===a.cur) cls+=" c";
      b.className=cls;
      b.textContent=String(i+1);
      b.onclick=()=>{a.cur=i;U.saveAttempt(a);render();};
      el.pal.appendChild(b);
    }
  }

  function render(){
    const q=qs[a.cur];
    el.qNo.textContent=`Q${a.cur+1}`;
    el.qText.textContent=(q.text?.en||"");
    el.opts.innerHTML="";
    (q.options?.en||[]).forEach((t,oi)=>{
      const d=document.createElement("div");
      d.className="opt"+(a.responses[a.cur]===oi?" sel":"");
      d.innerHTML=`<div class="pill">${String.fromCharCode(65+oi)}</div><div>${t}</div>`;
      d.onclick=()=>{a.responses[a.cur]=oi;U.saveAttempt(a);render();renderPal();};
      el.opts.appendChild(d);
    });
    el.mark.textContent = a.marked[a.cur] ? "Unmark" : "Mark";
    el.prev.disabled = a.cur===0;
    el.next.disabled = a.cur===qs.length-1;
  }

  el.mark.onclick=()=>{a.marked[a.cur]=!a.marked[a.cur];U.saveAttempt(a);render();renderPal();};
  el.clear.onclick=()=>{a.responses[a.cur]=null;U.saveAttempt(a);render();renderPal();};
  el.prev.onclick=()=>{if(a.cur>0){a.cur--;U.saveAttempt(a);render();renderPal();}}
  el.next.onclick=()=>{if(a.cur<qs.length-1){a.cur++;U.saveAttempt(a);render();renderPal();}}

  function score(){
    let att=0, right=0, wrong=0, sc=0;
    for(let i=0;i<qs.length;i++){
      const r=a.responses[i];
      if(r==null) continue;
      att++;
      if(r===qs[i].answerIndex){right++;sc+=1}else{wrong++;sc-=1/3}
    }
    return {att,right,wrong,sc};
  }

  el.submit.onclick=()=>{
    a.submittedAt=Date.now();
    const s=score();
    a.score=s.sc;a.attempted=s.att;a.right=s.right;a.wrong=s.wrong;
    U.saveAttempt(a);
    location.href=`./result.html?test=${testId}&attempt=${encodeURIComponent(a.attemptId)}`;
  };

  // timer
  let last=Date.now();
  setInterval(()=>{
    const now=Date.now();
    const d=Math.floor((now-last)/1000);
    if(d>0){a.timeLeft=Math.max(0,a.timeLeft-d);last=now;U.saveAttempt(a);}
    el.timer.textContent=U.mmss(a.timeLeft);
    if(a.timeLeft<=0 && !a.submittedAt) el.submit.click();
  },1000);

  document.getElementById("whoPill").textContent=`${profile.name} • ${profile.email} • Mock ${testId}`;
  render(); renderPal();
})();
