Deploy: upload the entire folder so index.html is at root AND data/mocks/*.json exists.
